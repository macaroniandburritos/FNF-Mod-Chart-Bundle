local screenWidth = 1280 -- Define the screen width explicitly
local screenHeight = 720 -- Define the screen height explicitly
local opponentOffsetX = screenWidth / 4 -- Offset from the left for opponent arrows
local playerOffsetX = screenWidth * 3 / 4 -- Offset from the left for player arrows
local centerY = screenHeight / 2 -- Center of the screen on the y-axis

function onUpdate(elapsed)
    -- Lining up opponent arrows on the y-axis
    for i = 0, 3 do
        setPropertyFromGroup('opponentStrums', i, 'x', opponentOffsetX)
        setPropertyFromGroup('opponentStrums', i, 'y', centerY + (i * 50)) -- Adjust spacing as needed
    end

    -- Lining up player arrows on the y-axis
    for i = 4, 7 do
        setPropertyFromGroup('playerStrums', i - 4, 'x', playerOffsetX)
        setPropertyFromGroup('playerStrums', i - 4, 'y', centerY + ((i - 4) * 50)) -- Adjust spacing as needed
    end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    setProperty('health', getProperty('health') - 1 * ((getProperty('health') / 22)) / 6)
    doTweenZoom('camerazoom', 'camGame', 0.775, 0.15, 'quadInOut')
    cameraSetTarget('dad')
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    doTweenZoom('camerazoom', 'camGame', 0.725, 0.15, 'quadInOut')
    cameraSetTarget('boyfriend')
end
