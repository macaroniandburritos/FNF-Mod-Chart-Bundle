local shuffleInterval = 0.001 -- Time in seconds between shuffles
local timeSinceLastShuffle = 0

local function shuffle(array)
    for i = #array, 2, -1 do
        local j = math.random(1, i)
        array[i], array[j] = array[j], array[i]
    end
end

function onUpdate(elapsed)
    timeSinceLastShuffle = timeSinceLastShuffle + elapsed
    if timeSinceLastShuffle >= shuffleInterval then
        timeSinceLastShuffle = 0

        -- Define the positions you want to shuffle to
        local positionsOpponent = {
            {x = defaultOpponentStrumX0, y = defaultOpponentStrumY0},
            {x = defaultOpponentStrumX1, y = defaultOpponentStrumY1},
            {x = defaultOpponentStrumX2, y = defaultOpponentStrumY2},
            {x = defaultOpponentStrumX3, y = defaultOpponentStrumY3}
        }

        local positionsPlayer = {
            {x = defaultPlayerStrumX0, y = defaultPlayerStrumY0},
            {x = defaultPlayerStrumX1, y = defaultPlayerStrumY1},
            {x = defaultPlayerStrumX2, y = defaultPlayerStrumY2},
            {x = defaultPlayerStrumX3, y = defaultPlayerStrumY3}
        }

        -- Shuffle the positions
        shuffle(positionsOpponent)
        shuffle(positionsPlayer)

        -- Apply shuffled positions to the notes
        for i = 0, 3 do
            setPropertyFromGroup('opponentStrums', i, 'x', positionsOpponent[i + 1].x)
            setPropertyFromGroup('opponentStrums', i, 'y', positionsOpponent[i + 1].y)

            setPropertyFromGroup('playerStrums', i, 'x', positionsPlayer[i + 1].x)
            setPropertyFromGroup('playerStrums', i, 'y', positionsPlayer[i + 1].y)
        end
    end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    setProperty('health', getProperty('health') - 1 * ((getProperty('health') / 22)) / 6)
    doTweenZoom('camerazoom', 'camGame', 0.775, 0.15, 'quadInOut')
    cameraSetTarget('dad')
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    doTweenZoom('camerazoom', 'camGame', 0.725, 0.15, 'quadInOut')
    cameraSetTarget('boyfriend')
end
