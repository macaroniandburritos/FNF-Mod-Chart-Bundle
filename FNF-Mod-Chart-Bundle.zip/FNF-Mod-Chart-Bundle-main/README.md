# FNF-Mod-Chart-Bundle
PLEASE NOTE THAT ALL OF THIS IS MADE WITH AI‼️‼️‼️ i didnt make ANY of this since i cant code, thank you SO MUCH to microsoft copilot.. and you for downloading if you do i guess

if you want to add a script to your song, here are all the steps.

firstly, pick a script. i'm not sure if you have to do this, but do it just in case. remove the text after "script", and just leave the name as "script". then, copy the script to your clipboard.

next, go into your engine. go to:
mods > [your-mod-folder] > data > [your-song-data-folder]

finally, paste your script that you copied, and ta-da!

you can now play your song and the mod chart should work!

i don't think this works on SOME songs, while I was testing it, it didn't seem to work on a specific song, but i'm not sure why.

also, this gets updated constantly! like, a LOT. contact me or add a issue if you encounter a bug!
