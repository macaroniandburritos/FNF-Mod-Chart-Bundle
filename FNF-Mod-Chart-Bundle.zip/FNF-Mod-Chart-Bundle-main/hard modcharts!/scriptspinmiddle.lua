local screenWidth = 1280 -- Define the screen width explicitly
local screenHeight = 720 -- Define the screen height explicitly
local centerX = screenWidth / 2 - 100 -- Move left by 100 units
local centerY = screenHeight / 2 - 50 -- Move up by 50 units
local radiusOpponent = 100 -- Radius of the opponent's spinning circle
local radiusPlayer = 150 -- Radius of the player's spinning circle
local spinSpeed = 2 -- Speed of the spinning

function onUpdate(elapsed)
    songPos = getSongPosition()
    local currentBeat = (songPos / 1000) * (curBpm / 60)

    for i = 0, 3 do
        -- Opponent notes spinning in the middle
        local angle = currentBeat * spinSpeed + i * (math.pi / 2) -- 90 degrees apart
        local offsetX = radiusOpponent * math.cos(angle)
        local offsetY = radiusOpponent * math.sin(angle)
        setPropertyFromGroup('opponentStrums', i, 'x', centerX + offsetX)
        setPropertyFromGroup('opponentStrums', i, 'y', centerY + offsetY)
    end

    for i = 4, 7 do
        -- Player notes spinning in the middle
        local angle = currentBeat * spinSpeed + (i - 4) * (math.pi / 2) -- 90 degrees apart
        local offsetX = radiusPlayer * math.cos(angle)
        local offsetY = radiusPlayer * math.sin(angle)
        setPropertyFromGroup('playerStrums', i - 4, 'x', centerX + offsetX)
        setPropertyFromGroup('playerStrums', i - 4, 'y', centerY + offsetY)
    end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    setProperty('health', getProperty('health') - 1 * ((getProperty('health') / 22)) / 6)
    doTweenZoom('camerazoom', 'camGame', 0.775, 0.15, 'quadInOut')
    cameraSetTarget('dad')
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    doTweenZoom('camerazoom', 'camGame', 0.725, 0.15, 'quadInOut')
    cameraSetTarget('boyfriend')
end
