local amplitude = 300 -- Very strong wave effect
local frequency = 10 -- Very fast wave effect

function onUpdate(elapsed)
    songPos = getSongPosition()
    local currentBeat = (songPos / 1000) * (curBpm / 60)

    for i = 0, 3 do
        -- Opponent notes with very strong and fast wave effect along the y-axis
        local offsetY = amplitude * math.sin((currentBeat * frequency) + (i * math.pi / 2))
        setPropertyFromGroup('opponentStrums', i, 'y', defaultOpponentStrumY0 + offsetY)
    end

    for i = 4, 7 do
        -- Player notes with very strong and fast wave effect along the y-axis
        local offsetY = amplitude * math.sin((currentBeat * frequency) + ((i - 4) * math.pi / 2))
        setPropertyFromGroup('playerStrums', i - 4, 'y', defaultPlayerStrumY0 + offsetY)
    end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    setProperty('health', getProperty('health') - 1 * ((getProperty('health') / 22)) / 6)
    doTweenZoom('camerazoom', 'camGame', 0.775, 0.15, 'quadInOut')
    cameraSetTarget('dad')
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    cameraShake(game, 0.0015, 0.15)
    doTweenZoom('camerazoom', 'camGame', 0.725, 0.15, 'quadInOut')
    cameraSetTarget('boyfriend')
end
